﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LB_GameManager : MonoBehaviour 
{

    public int tileCount;

    public int qLives;


	// Use this for initialization
	void Start () 
    {
        tileCount = 0;
        qLives = 2;	
	}
	
	// Update is called once per frame
	void Update () 
    {
	    	

	}


}
