﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AS_Score : MonoBehaviour 
{
	public ST_ColorChange scoreColor;

	void Start () 
	{
		
	}

	void Update () 
	{
		
	}
}
